Jacob Choi - echoi51
Darren Shih - dshih5

Milestone 1
Jacob, Darren - We met and worked on implementing all helper functions and used them 
to implement all 5 drawing functions altogether. Jacob took care of fixing existing 
bugs in the code while Darren worked on building unit tests for each helper function
to ensure our code runs correctly.

Milestone 2
Jacob, Darren - We met and worked on implementing all of our required helper functions 
in Assembly language altogether. Jacob worked on building the base for all functions 
and Darren worked on fixing and debugging the current code to avoid any bugs or segfaults

Milestone 3
Jacob, Darren - We met and worked on implementing the rest of our drawing functions 
in the Assembly language together except for draw_tile and draw_sprite due to some issues. 
Darren worked on building the base for the rest of these functions while Jacob workedon 
fixing and debugging the base code to avoid any bugs or segfaults. We also added comments 
together.