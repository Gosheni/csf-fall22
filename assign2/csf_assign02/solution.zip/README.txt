Jacob Choi - echoi51
Darren Shih - dshih5

Milestone 1
Jacob, Darren - We met and worked on implementing all helper functions and used them 
to implement all 5 drawing functions altogether. Jacob took care of fixing existing 
bugs in the code while Darren worked on building unit tests for each helper function
to ensure our code runs correctly.