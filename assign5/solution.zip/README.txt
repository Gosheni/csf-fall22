Jacob Choi - echoi51
Darren Shih - dshih5

Assignment 5 - Milestone 1
Jacob, Darren - We met and worked on constructing the base for Assignment 5 chat server
project. We implemented the code for connection server, the sender client, and the receiver 
client. After that, we discussed about our bugs and fixed the bugs together.

Assignment 5 - Milestone 2
Jacob, Darren - We met and worked on completing the server part for Assignment 5 chat server
project. We implemented the code for the server part. After that, we discussed about our bugs 
and fixed the bugs together.
