Jacob Choi - echoi51
Darren Shih - dshih5

Milestone 1
Jacob, Darren - We met and worked on constructing typedef Fixedpoint, enum TagType, and the five functions 
in fixedpoint.c (fixedpoint_create, fixedpoint_create2, fixedpoint_whole_part, fixedpoint_frac_part, fixedpoint_is_zero)

Milestone 2
Jacob worked on the functions create_from_hex, add, sub, halve, double, negate, compare, valid, and the base unit tests for all functions
Darren worked on the rest of the remaining functinos and worked on adding edge cases to the unit tests.
We collectively worked on solving all the bugs and memory leak problems together as well as improving the redability of the code by adding comments. 