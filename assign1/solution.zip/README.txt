Jacob Choi - echoi51
Darren Shih - dshih5

Jacob, Darren - We met and worked on constructing typedef Fixedpoint, enum TagType, and the five functions 
in fixedpoint.c (fixedpoint_create, fixedpoint_create2, fixedpoint_whole_part, fixedpoint_frac_part, fixedpoint_is_zero)