#ifndef CACHE_HPP
#define CACHE_HPP

#include <iostream>
#include <vector>
#include "Set.hpp"
#include "Slot.hpp"

namespace Csim 
{
  class Cache {

  public:
    // This default constructor initializes a board with the standard
    // piece positions, and sets the state to white's turn
    Cache();

    Cache(std::vector<Set> &s, uint32_t b, bool all, bool wr, bool l, int t);
    
    // Copy constructor
    Cache(const Cache& cache);

    // Deconstructor helper function
    void delete_cache();

    bool loadStore(uint32_t ad, uint32_t ind, size_t n, bool dirty, bool store);

    void setSets(std::vector<Set> &s);
    
    void setByte(uint32_t b);
    
    void setAllocate(bool all);

    void setWrite(bool wr);

    void setLru(bool lru);

    void setType(int t);

    void setCycles(unsigned long c);

    unsigned long getCycles();
    
  private:
    std::vector<Set> sets;
    uint32_t byte;
    bool allocate;
    bool write;
    bool lru;
    int type; // 1 -> Direct, 2 -> Set, 3 -> Full 
    unsigned long cycles;
  };
}

#endif