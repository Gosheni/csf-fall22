#include <iostream>
#include <vector>
#include <map>
#include "Set.hpp"
#include "Slot.hpp"

namespace Csim 
{
    Set::Set() {}

    Set::Set(std::vector<Slot>& s) {
        slots = s;
        std::map<uint32_t, int> map;
        index = map;
        size = 0;
    }

    std::vector<Slot> Set::getSlots() {
        return slots;
    }

    void Set::setSlots(std::vector<Slot>& s) {
        slots = s;
    }

    void Set::setMap(std::map<uint32_t, int>& m) {
        index = m;
    }

    void Set::setSize(int s) {
        size = s;
    }

    int Set::getSize() {
        return size;
    }

    void Set::incSize() {
        size++;
    }

    std::map<uint32_t, int> Set::getIndex() {
        return index;
    }
}