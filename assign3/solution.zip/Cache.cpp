#include <iostream>
#include <vector>
#include "Cache.hpp"
#include "Set.hpp"
#include "Slot.hpp"

namespace Csim 
{
    Cache::Cache(){}

    Cache::Cache(std::vector<Set> &s, uint32_t b, bool all, bool wr, bool l, int t) {
        sets = s;
        byte = b;
        allocate = all;
        write = wr;
        lru = l;
        type = t;
        cycles = 0;
    }

    //Copy constructor
    Cache::Cache(const Cache& cache) {
      sets = cache.sets;
      allocate = cache.allocate;
      write = cache.write;
      lru = cache.lru;
      type = cache.type;
      cycles = 0;
    }

    // Deconstructor helper function
    void Cache::delete_cache() {
      sets.clear();
      byte = 0;
      allocate = false;
      write = false;
      lru = false;
      type = 0;
      cycles = 0;
    }

    bool Cache::loadStore(uint32_t ad, uint32_t ind, size_t n, bool dirty, bool store) {
        bool hit = false;
        int toRem = -1;

        //Initializing slot
        Slot slot; 
        slot.setTag(ad);
        slot.setValid(!dirty);

        std::vector<Slot> block = sets[ind].getSlots();
        std::map<uint32_t, int> map = sets[ind].getIndex();
        if (type == 3) { //Full-associative
            auto it = map.find(ad);
            if (it != map.end()) { //hit
                toRem = it->second;
                hit = true;
            } else { //miss
                //Find n-1 (See if set is full)
                int size = sets[0].getSize();
                for (int i = 0; i < size; i++) {
                    if (block[i].getTs() == n-1) {
                        toRem = i;
                        break;
                    }
                }
            }
        } else { //Direct or Set-associative
            int size = sets[ind].getSize();
            for (int i = 0; i < size; i++) {
                if (block[i].getTs() == n-1) { //Save index, if n-1 found
                    toRem = i;
                }
                if (block[i].getTag() == ad) { //hit
                    toRem = i;
                    hit = true;
                    break;
                }
            }
        }

        if (!hit) {
            if (store && !allocate && write) { // store & no-allocate & write-through
                return false;
            }
            if (type == 3 && toRem > -1) { //Full-associative and found n-1
                map.erase(block[toRem].getTag());
            }
            if (toRem > -1 && !block[toRem].isValid()) cycles += byte/4*100;
            else if(toRem == -1) { //If not found, then can increase size
                toRem = sets[ind].getSize();
                sets[ind].incSize();
                slot.setTs(n-1);
                block[toRem] = slot;
            }
            if (type == 3) { //Full-associative
                map[ad] = toRem;
            }
        } 
    
        if (lru || !hit) {
            // Increase ts of all blocks with ts less than parameter
            int size = sets[ind].getSize();
            for (int i = 0; i < size; i++) {
                if (block[i].getTs() < block[toRem].getTs()) {
                    block[i].incTs();
                }
            }
            //Set slot and assign
            slot.setTs(0);
            block[toRem] = slot;
            sets[ind].setSlots(block);
            sets[ind].setMap(map);
        }
        return hit;
    }

    void Cache::setSets(std::vector<Set> &s) {
        sets = s;
    }

    void Cache::setByte(uint32_t b) {
      byte = b;
    }

    void Cache::setAllocate(bool all) {
      allocate = all;
    }

    void Cache::setWrite(bool wr) {
      write = wr;
    }

    void Cache::setLru(bool lru) {
      lru = lru;
    }

    void Cache::setType(int t) {
      type = t;
    }

    void Cache::setCycles(unsigned long c) {
      cycles = c;
    }

    unsigned long Cache::getCycles() {
      return cycles;
    }
}