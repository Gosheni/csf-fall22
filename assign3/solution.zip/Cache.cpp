#include <iostream>
#include <vector>
#include "Cache.hpp"
#include "Set.hpp"
#include "Slot.hpp"

struct Slot {
    uint32_t tag;
    bool valid;
    unsigned long timestamp;
};

struct Set {
    std::vector<Slot> slots;
    std::map<unsigned long, unsigned long> index; //map of tag to index of slot
    unsigned long size;
};

namespace Csim 
{
    Cache::Cache(){}

    Cache::Cache(std::vector<Set>* s, bool all, bool wr, bool l, int t) {
        sets = *s;
        allocate = all;
        write = wr;
        lru = l;
        type = t;
        cycles = 0;
    }

    //Copy constructor
    Cache::Cache(const Cache& cache) {
      sets = cache.sets;
      allocate = cache.allocate;
      write = cache.write;
      lru = cache.lru;
      type = cache.type;
      cycles = 0;
    }

    // Deconstructor helper function
    void Cache::delete_cache() {
      sets.clear();
    }

    void updateTs(Cache &c, uint32_t max, uint32_t index) {
    for (size_t j = 0; j < c.sets[index].size; j++) {
        if (c.sets[index].slots[j].timestamp < max) {
            c.sets[index].slots[j].timestamp++;
        }
    }
}

bool callLoad(Cache &c, uint32_t ad, uint32_t index, size_t n) {
    //Load
    bool hit = false;
    int toRem = -1;
      
    Slot slot; //Initializing slot
    slot.tag = ad;
    slot.timestamp = 0;
    slot.valid = true;

    std::vector<Slot> block = c.sets[index].slots;
    for (size_t i = 0; i < c.sets[index].size; i++) {
        if (block[i].timestamp >= n-1) toRem = i;
        if (block[i].tag == ad) { // Means it's hit
            for (size_t j = 0; j < c.sets[index].size; j++) { // Increase ts of all blocks with ts less than parameter
                if (block[j].timestamp < block[i].timestamp) {
                    block[j].timestamp++;
                }
            } 
            block[i].timestamp = 0;
            hit = true;
            break;
        } 
    }
    if (!hit) {
        for (size_t j = 0; j < c.sets[index].size; j++) { // Increase ts of all blocks with ts less than parameter
            if (block[j].timestamp < n-1) {
                block[j].timestamp++;
            }
        } 
        if (toRem == -1) {
            toRem = c.sets[index].size;
            c.sets[index].size++;
        }
        block[toRem] = slot;
        
    }
    c.sets[index].slots = block; // See if this is necessary
    return hit;
}

bool callStore(Cache &c, uint32_t ad, uint32_t index, size_t n) {
    //Load
    return callLoad(c, ad, index, n);
}

bool callLoadFull(Cache &c, uint32_t ad, size_t n) {
    //Load
    bool hit = false;
    int toRem = -1;

    Slot slot; //Initializing slot
    slot.tag = ad;
    slot.timestamp = 0;
    slot.valid = true;

    std::map<unsigned long, unsigned long> temp = c.sets[0].index;
    std::vector<Slot> block = c.sets[0].slots;
    for (size_t i = 0; i < c.sets[0].size; i++) {
        if (block[i].timestamp >= n-1) toRem = i;
        if (block[i].tag == ad) { // Means it's hit
            for (size_t j = 0; j < c.sets[0].size; j++) { // Increase ts of all blocks with ts less than parameter
                if (block[j].timestamp < block[i].timestamp) {
                    block[j].timestamp++;
                }
            } 
            block[i].timestamp = 0;
            hit = true;
            break;
        } 
    }
    if (!hit) {
        for (size_t j = 0; j < c.sets[0].size; j++) { // Increase ts of all blocks with ts less than parameter
            if (block[j].timestamp < n-1) {
                block[j].timestamp++;
            }
        } 
        if (toRem == -1) {
            toRem = c.sets[0].size;
            c.sets[0].size++;
        }
        block[toRem] = slot;
        

        temp[ad] = toRem;
        c.sets[0].index = temp; // See if necessary
    } 
    c.sets[0].slots = block; // See if necessary
    return hit;
}

bool callStoreFull(Cache &c, uint32_t ad, size_t n) {
    //Load
    return callLoadFull(c, ad, n);
}

bool storeMemory(Cache &c, uint32_t ad, uint32_t index) {
    //Load
    bool hit = false;
    std::vector<Slot> block = c.sets[index].slots;
    for (size_t i = 0; i < c.sets[index].size; i++) {
        if (block[i].tag == ad) { // If it's a hit
            for (size_t j = 0; j < c.sets[index].size; j++) { // Increase ts of all blocks with ts less than parameter
                if (block[j].timestamp < block[i].timestamp) {
                    block[j].timestamp++;
                }
            } 
            block[i].timestamp = 0;
            hit = true;
            break;
        } 
    }
    if (hit) c.sets[0].slots = block; // If it's store miss, sets doesn't get updated
    return hit;
}

bool storeMemoryFull(Cache &c, uint32_t ad) {

    std::map<unsigned long, unsigned long> m = c.sets[0].index;
    std::map<unsigned long, unsigned long>::iterator it = m.find(ad); // Check if map gets updated
    if (m.empty() || it == c.sets[0].index.end()) return false; // Store miss 

    std::vector<Slot> block = c.sets[0].slots;
    for (size_t i = 0; i < c.sets[0].size; i++) {
        if (block[i].tag == ad) { // If it's a hit
            block[i].timestamp = 0; // Reset ts to 0
        } else {
            block[i].timestamp++; // Else inc ts
        }
    }
    c.sets[0].slots = block;
    return true; // Store hit
}

bool dirty(Cache &c, uint32_t ad, uint32_t index, size_t n, uint32_t byte, bool l) {
    //Load
    bool hit = false;
    int toRem = -1;
      
    Slot slot; //Initializing slot
    slot.tag = ad;
    slot.timestamp = 0;
    slot.valid = l ? true : false;

    std::vector<Slot> block = c.sets[index].slots;
    for (size_t i = 0; i < c.sets[index].size; i++) {
        if (block[i].timestamp == n-1) toRem = i;
        if (block[i].tag == ad) { // Means it's hit
            for (size_t j = 0; j < c.sets[index].size; j++) { // Increase ts of all blocks with ts less than parameter
                if (block[j].timestamp < block[i].timestamp) {
                    block[j].timestamp++;
                }
            } 
            block[i].timestamp = 0;
            hit = true;
            break;
        } 
    }
    if (!hit) {
        for (size_t j = 0; j < c.sets[index].size; j++) { // Increase ts of all blocks with ts less than parameter
            if (block[j].timestamp < n-1) {
                block[j].timestamp++;
            }
        } 
        if (toRem > -1 && !block[toRem].valid) c.cycles += byte/4*100;
        else if (toRem == -1) {
            toRem = c.sets[index].size;
            c.sets[index].size++;
        }
        block[toRem] = slot;
    } 
    c.sets[index].slots = block;
    return hit;
}

bool dirtyFull(Cache &c, uint32_t ad, size_t n, uint32_t byte, bool l) {
    //Load
    bool hit = false;
    int toRem = -1;

    Slot slot; //Initializing slot
    slot.tag = ad;
    slot.timestamp = 0;
    slot.valid = l ? true : false;

    std::map<unsigned long, unsigned long> temp = c.sets[0].index;
    std::vector<Slot> block = c.sets[0].slots;
    for (size_t i = 0; i < c.sets[0].size; i++) {
        if (block[i].timestamp == n-1) toRem = i; // Save the index of highest ts
        if (block[i].tag == ad) { // Means it's hit
            for (size_t j = 0; j < c.sets[0].size; j++) { // Increase ts of all blocks with ts less than parameter
                if (block[j].timestamp < block[i].timestamp) {
                    block[j].timestamp++;
                }
            } 
            block[i].timestamp = 0;
            hit = true;
            break;
        } 
    }
    if (!hit) {
        for (size_t j = 0; j < c.sets[0].size; j++) { // Increase ts of all blocks with ts less than parameter
            if (block[j].timestamp < n-1) {
                block[j].timestamp++;
            }
        } 
        if (toRem > -1 && !block[toRem].valid) c.cycles += byte/4*100;
        else if (toRem == -1) {
            toRem = c.sets[0].size;
            c.sets[0].size++;
        }
        block[toRem] = slot;
        temp[ad] = toRem;
        c.sets[0].index = temp;
    } 
    c.sets[0].slots = block;
    return hit;
}

    bool Cache::getAllocate() {
      return allocate;
    }

    bool Cache::getWrite() {
      return write;
    }

    bool Cache::getLru() {
      return lru;
    }

    int Cache::getType() {
      return type;
    }

    unsigned long Cache::getCycles() {
      return cycles;
    }

    std::vector<Set> Cache::getSet() {
      return sets;
    }
}