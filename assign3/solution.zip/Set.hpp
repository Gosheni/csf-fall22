#ifndef SET_HPP
#define SET_HPP

#include <iostream>
#include <vector>
#include <map>
#include "Slot.hpp"

namespace Csim 
{
    class Set {

    public:
        Set();
    
        Set(std::vector<Slot>& s);
    
        std::vector<Slot> getSlots();

        void setSlots(std::vector<Slot>& s);

        void setMap(std::map<uint32_t, int>& m);

        void setSize(int s);

        int getSize();

        void incSize();

        std::map<uint32_t, int> getIndex();
    
    private:
        std::vector<Slot> slots;
        std::map<uint32_t, int> index; //map of tag to index of slot
        int size;
    };
}

#endif