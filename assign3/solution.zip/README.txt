Jacob Choi - echoi51
Darren Shih - dshih5

Milestone 1
Jacob, Darren - We met and worked on constructing the base for Assignment 3 cache project. 
We implemented our cpp code as far as to handling arguments and running without any issues.

Milestone 2
Jacob, Darren - We met and worked on constructing our cache simulator using different cpp 
and hpp files. After construction, Jacob and Darren focused on reducing the size and efficiency
of our code.